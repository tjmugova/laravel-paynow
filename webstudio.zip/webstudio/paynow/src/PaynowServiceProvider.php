<?php

namespace Webstudio\Paynow;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

class PaynowServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {

    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
